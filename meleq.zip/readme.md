
## CMS Resume

Aplikasi Content Management System(CMS) untuk [Resume](https://themeforest.net/item/lonon-resume-portfolio-template/24100324)


#### Teknologi
- [Codeigniter](https://codeigniter.com)
- [PHP](https://php.net)