
            <!-- Footer -->
            <div id="lonon-footer2">
                <div class="lonon-narrow-content">
                    <div class="row">
                        <div class="col-md-4 animate-box" data-animate-effect="fadeInLeft">
                            <p class="lonon-lead">&copy; 2019 Lonon. All rights reserved</p>
                        </div>
                        <div class="col-md-4 animate-box" data-animate-effect="fadeInLeft">
                            <h2 class="text-center">Andrika Permana</h2> </div>
                        <div class="col-md-4 animate-box" data-animate-effect="fadeInLeft">
                            <ul class="social-network">
                                <li><a href="#"><i class="ti-facebook font-14px black-icon"></i></a></li>
                                <li><a href="#"><i class="ti-twitter-alt font-14px black-icon"></i></a></li>
                                <li><a href="#"><i class="ti-instagram font-14px black-icon"></i></a></li>
                                <li><a href="#"><i class="ti-linkedin font-14px black-icon"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Js -->
        <script src="<?php echo base_url('assets/frontend/js/jquery.min.js')?>"></script>
        <script src="<?php echo base_url('assets/frontend/js/modernizr-2.6.2.min.js')?>"></script>
        <script src="<?php echo base_url('assets/frontend/js/jquery.easing.1.3.js')?>"></script>
        <script src="<?php echo base_url('assets/frontend/js/bootstrap.min.js')?>"></script>
        <script src="<?php echo base_url('assets/frontend/js/jquery.waypoints.min.js')?>"></script>
        <script src="<?php echo base_url('assets/frontend/js/sticky-kit.min.js')?>"></script>
        <script src="<?php echo base_url('assets/frontend/js/main.js')?>"></script>
    </div>
</body>



</html>